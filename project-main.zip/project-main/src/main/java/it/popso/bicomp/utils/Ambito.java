package it.popso.bicomp.utils;

public enum Ambito {
	
	RT1,
	TIPS,
	CGS

}
