package it.popso.bicomp.utils;

public enum FeedbackStatus {
	
	INSERITO,
	IN_LAVORAZIONE,
	ANNULLATO,
	RISOLTO

}
