package it.popso.bicomp.model;

public enum NotificationLevelEnum {
	
	ERROR, INFO, WARN

}
