package it.popso.bicomp.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import it.popso.bicomp.dto.CgsLacDetailDto;
import it.popso.bicomp.dto.CgsLacDto;
import it.popso.bicomp.dto.CgsLacEntryDto;
import it.popso.bicomp.dto.PageableCgsEntryDto;
import it.popso.bicomp.exception.BicompException;
import it.popso.bicomp.exception.ResourceNotFoundException;
import it.popso.bicomp.service.CgsService;


@ExtendWith(SpringExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@TestMethodOrder(OrderAnnotation.class)
class CgsControllerTest {
	
	@Mock
	private CgsService cgsService;
	
	private CgsController controller;
	

	@BeforeEach
	public void setup() {
		this.controller = new CgsController(this.cgsService);
	}
	
	@Test
	@Order(1)
	void testGetLastCgsBalance() throws ResourceNotFoundException, ParseException {
		
		List<CgsLacDto> list = Arrays.asList(CgsLacDto.builder()
				.lacId(new BigDecimal(1))
				.lacNumber("01")
				.fromDateTime(LocalDateTime.now())
				.toDateTime(LocalDateTime.now())
				.openingBalance(new BigDecimal(100))
				.closingBalance(new BigDecimal(200))
				.currency("EUR")
				.build()
			);
		Mockito.when(this.cgsService.getCgsLastBalanceByDate(Mockito.anyString())).thenReturn(list);
		
		List<CgsLacDto> result = (List<CgsLacDto>) this.controller.getLastCgsLac("01-09-2023").getBody().getResponse();
		
		assertThat(result).isNotEmpty().hasSameSizeAs(list);
		assertThat(result.get(0).getLacNumber()).isEqualTo(list.get(0).getLacNumber());
		
		verify(this.cgsService, times(1)).getCgsLastBalanceByDate(Mockito.anyString());
	}
	
	@Test
	@Order(2)
	void testGetLastCgsBalanceException() throws ResourceNotFoundException, ParseException {
		
		Mockito.when(this.cgsService.getCgsLastBalanceByDate(Mockito.anyString())).thenThrow(ResourceNotFoundException.class);
		
		assertThrows(ResourceNotFoundException.class, () -> {
			this.controller.getLastCgsLac("01-09-2023");
		});
		
		verify(this.cgsService, times(1)).getCgsLastBalanceByDate(Mockito.anyString());
	}
	
	@Test
	@Order(3)
	void testGetCgsLacs() throws ResourceNotFoundException, ParseException {
		
		List<CgsLacDto> list = Arrays.asList(CgsLacDto.builder()
				.lacId(new BigDecimal(1))
				.lacNumber("01")
				.fromDateTime(LocalDateTime.now())
				.toDateTime(LocalDateTime.now())
				.openingBalance(new BigDecimal(100))
				.closingBalance(new BigDecimal(200))
				.currency("EUR")
				.build(), CgsLacDto.builder()
				.lacId(new BigDecimal(2))
				.lacNumber("02")
				.fromDateTime(LocalDateTime.now())
				.toDateTime(LocalDateTime.now())
				.openingBalance(new BigDecimal(300))
				.closingBalance(new BigDecimal(200))
				.currency("EUR")
				.build()
			);
		Mockito.when(this.cgsService.getCurrentDateLac(Mockito.anyString())).thenReturn(list);
		
		List<CgsLacDto> result = (List<CgsLacDto>) this.controller.getCgsLacs("01-09-2023").getBody().getResponse();
		
		assertThat(result).isNotEmpty().hasSameSizeAs(list);
		assertThat(result.get(1).getLacNumber()).isEqualTo(list.get(1).getLacNumber());
		
		verify(this.cgsService, times(1)).getCurrentDateLac(Mockito.anyString());
	}
	
	@Test
	@Order(4)
	void testGetCgsLacsException() throws ResourceNotFoundException, ParseException {
		
		Mockito.when(this.cgsService.getCurrentDateLac(Mockito.anyString())).thenThrow(ResourceNotFoundException.class);
		
		assertThrows(ResourceNotFoundException.class, () -> {
			this.controller.getCgsLacs("01-09-2023");
		});
		
		verify(this.cgsService, times(1)).getCurrentDateLac(Mockito.anyString());
	}
	
	@Test
	@Order(5)
	void testGetCgsLacDetail() {
		
		CgsLacDetailDto cgsLacDetailDto = CgsLacDetailDto .builder()
				.lacId(new BigDecimal(1))
				.lacNumber("01")
				.creditLtinAmount(new BigDecimal(100))
				.debitLtinAmount(BigDecimal.ZERO)
				.sctCreditPmntAmount(new BigDecimal(300))
				.sctDebitPmntAmount(new BigDecimal(200))
				.b2bCreditPmntAmount(new BigDecimal(100))
				.b2bDebitPmntAmount(BigDecimal.ZERO)
				.corCreditPmntAmount(new BigDecimal(50))
				.corDebitPmntAmount(new BigDecimal(150))
				.pendingDebitPmntAmount(BigDecimal.ZERO)
				.currency("EUR")
				.build();
		Mockito.when(this.cgsService.getLacDetail(Mockito.any(BigDecimal.class))).thenReturn(cgsLacDetailDto);
		
		CgsLacDetailDto result = (CgsLacDetailDto) this.controller.getCgsLacDetail(BigDecimal.ONE).getBody().getResponse();
		
		assertThat(result).isNotNull();
		assertThat(result.getLacNumber()).isEqualTo(cgsLacDetailDto.getLacNumber());
		assertThat(result.getSctCreditPmntAmount()).isEqualTo(cgsLacDetailDto.getSctCreditPmntAmount());
		
		verify(this.cgsService, times(1)).getLacDetail(Mockito.any(BigDecimal.class));
	}
	
	@Test
	@Order(6)
	void testGetCgsLacDetailException() {
		
		Mockito.when(this.cgsService.getLacDetail(Mockito.any(BigDecimal.class))).thenThrow(ResourceNotFoundException.class);
		
		assertThrows(ResourceNotFoundException.class, () -> {
			this.controller.getCgsLacDetail(BigDecimal.ONE);
		});
		
		verify(this.cgsService, times(1)).getLacDetail(Mockito.any(BigDecimal.class));
	}
	
	/*@Test
	@Order(7)
	void testGetDebitCreditLiquidityTransfer() throws ResourceNotFoundException, ParseException {
		
		PageableCgsEntryDto p = PageableCgsEntryDto.builder()
				.totalElements(new BigDecimal(2))
				.entries(Arrays.asList(CgsLacEntryDto.builder()
						.entryId(new BigDecimal(1))
						.entryReference("CG2306050000069T")
						.paymentAmount(new BigDecimal(100))
						.currency("EUR")
						.side('C')
						.service("SCT")
						.status("BOOK")
						.settlementDateTime(new Timestamp(System.currentTimeMillis()))
						.additionalInfo("C-FUND")
						.build(), CgsLacEntryDto.builder()
						.entryReference("CG2306050000069V")
						.paymentAmount(new BigDecimal(200))
						.currency("EUR")
						.side('C')
						.service("SCT")
						.status("BOOK")
						.settlementDateTime(new Timestamp(System.currentTimeMillis()))
						.additionalInfo("C-FUND")
						.build())
				)
				.build();
		Mockito.when(this.cgsService.getDebitCreditLiquidityTransfer(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.any(Pageable.class)))
			.thenReturn(p);
		
		PageableCgsEntryDto result = (PageableCgsEntryDto) this.controller.getDebitCreditLiquidityTransfer(BigDecimal.ONE, 'C', 0, 10)
				.getBody().getResponse();
		
		assertThat(result).isNotNull();
		assertThat(result.getEntries()).hasSameSizeAs(p.getEntries());
		assertThat(result.getEntries().get(0).getEntryReference()).isEqualTo(p.getEntries().get(0).getEntryReference());
		
		verify(this.cgsService, times(1)).getDebitCreditLiquidityTransfer(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.any(Pageable.class));
	}
	
	@Test
	@Order(8)
	void testGetDebitCreditLiquidityTransferException() throws ResourceNotFoundException, ParseException {
		
		Mockito.when(this.cgsService.getDebitCreditLiquidityTransfer(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.any(Pageable.class)))
			.thenThrow(ResourceNotFoundException.class);
		
		assertThrows(ResourceNotFoundException.class, () -> {
			this.controller.getDebitCreditLiquidityTransfer(BigDecimal.ONE, 'C', 0, 10);
		});
		
		verify(this.cgsService, times(1)).getDebitCreditLiquidityTransfer(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.any(Pageable.class));
	}
	
	@Test
	@Order(9)
	void testGetDebitCreditPayment() throws ParseException {
		
		PageableCgsEntryDto p = PageableCgsEntryDto.builder()
				.totalElements(new BigDecimal(2))
				.entries(Arrays.asList(CgsLacEntryDto.builder()
						.entryId(new BigDecimal(1))
						.entryReference("CSR2306065016070")
						.paymentAmount(new BigDecimal(100))
						.currency("EUR")
						.side('C')
						.service("SCT")
						.status("BOOK")
						.settlementDateTime(new Timestamp(System.currentTimeMillis()))
						.debitor("BCITITMMXXX")
						.creditor("POSOIT22XXX")
						.additionalInfo("LCR-SETTLEDNOTPROVIDED")
						.build(), CgsLacEntryDto.builder()
						.entryReference("CSR2306065016071")
						.paymentAmount(new BigDecimal(200))
						.currency("EUR")
						.side('C')
						.service("SCT")
						.status("BOOK")
						.settlementDateTime(new Timestamp(System.currentTimeMillis()))
						.debitor("BCITITMMXXX")
						.creditor("POSOIT22XXX")
						.additionalInfo("LCR-SETTLEDNOTPROVIDED")
						.build())
				)
				.build();
		Mockito.when(this.cgsService.getDebitCreditPayment(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), 
				Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.anyString(), Mockito.any(Pageable.class)))
			.thenReturn(p);
		
		PageableCgsEntryDto result = (PageableCgsEntryDto) this.controller.getDebitCreditPayment(BigDecimal.ONE, 'C', "BOOK", 0, 10)
				.getBody().getResponse();
		
		assertThat(result).isNotNull();
		assertThat(result.getEntries()).hasSameSizeAs(p.getEntries());
		assertThat(result.getEntries().get(1).getEntryReference()).isEqualTo(p.getEntries().get(1).getEntryReference());
		
		verify(this.cgsService, times(1)).getDebitCreditPayment(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), 
				Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.anyString(), Mockito.any(Pageable.class));
	}
	
	@Test
	@Order(10)
	void testGetDebitCreditPaymentResourceNotFoundException() throws ParseException {
		
		Mockito.when(this.cgsService.getDebitCreditPayment(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), 
				Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.anyString(), Mockito.any(Pageable.class)))
			.thenThrow(ResourceNotFoundException.class);
		
		assertThrows(ResourceNotFoundException.class, () -> {
			this.controller.getDebitCreditPayment(BigDecimal.ONE, 'C', "BOOK", 0, 10);
		});
		
		verify(this.cgsService, times(1)).getDebitCreditPayment(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), 
				Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.anyString(), Mockito.any(Pageable.class));
	}
	
	@Test
	@Order(11)
	void testGetDebitCreditPaymentBicompException() throws ParseException {
		
		Mockito.when(this.cgsService.getDebitCreditPayment(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), 
				Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.anyString(), Mockito.any(Pageable.class)))
			.thenThrow(ParseException.class);
		
		assertThrows(BicompException.class, () -> {
			this.controller.getDebitCreditPayment(BigDecimal.ONE, 'C', "BOOK", 0, 10);
		});
		
		verify(this.cgsService, times(1)).getDebitCreditPayment(Mockito.any(BigDecimal.class), Mockito.anyChar(), Mockito.isNull(), 
				Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.isNull(), Mockito.anyString(), Mockito.any(Pageable.class));
	}
	
	@Test
	@Order(12)
	void testGetDebitCreditPaymentFilter() throws ParseException {
		
		PageableCgsEntryDto p = PageableCgsEntryDto.builder()
				.totalElements(new BigDecimal(2))
				.entries(Arrays.asList(CgsLacEntryDto.builder()
						.entryId(new BigDecimal(1))
						.entryReference("CSR2306065016070")
						.paymentAmount(new BigDecimal(100))
						.currency("EUR")
						.side('C')
						.service("SCT")
						.status("BOOK")
						.settlementDateTime(new Timestamp(System.currentTimeMillis()))
						.debitor("BCITITMMXXX")
						.creditor("POSOIT22XXX")
						.additionalInfo("LCR-SETTLEDNOTPROVIDED")
						.build(), CgsLacEntryDto.builder()
						.entryReference("CSR2306065016071")
						.paymentAmount(new BigDecimal(200))
						.currency("EUR")
						.side('C')
						.service("SCT")
						.status("BOOK")
						.settlementDateTime(new Timestamp(System.currentTimeMillis()))
						.debitor("BCITITMMXXX")
						.creditor("POSOIT22XXX")
						.additionalInfo("LCR-SETTLEDNOTPROVIDED")
						.build())
				)
				.build();
		Mockito.when(this.cgsService.getDebitCreditPayment(Mockito.isNull(), Mockito.anyChar(), Mockito.any(BigDecimal.class), 
				Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(Pageable.class)))
			.thenReturn(p);
		
		PageableCgsEntryDto result = (PageableCgsEntryDto) this.controller.getDebitCreditPaymentFilter('C', "BOOK", 
				new BigDecimal(10), new BigDecimal(100), "2023-06-09T10:00", "2023-06-09T12:00", "SCT", 0, 10)
			.getBody().getResponse();
		
		assertThat(result).isNotNull();
		assertThat(result.getEntries()).hasSameSizeAs(p.getEntries());
		assertThat(result.getEntries().get(1).getEntryReference()).isEqualTo(p.getEntries().get(1).getEntryReference());
		
		verify(this.cgsService, times(1)).getDebitCreditPayment(Mockito.isNull(), Mockito.anyChar(), Mockito.any(BigDecimal.class), 
				Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(Pageable.class));
	}
	
	@Test
	@Order(13)
	void testGetDebitCreditPaymentFilterResourceNotFoundException() throws ParseException {
		
		Mockito.when(this.cgsService.getDebitCreditPayment(Mockito.isNull(), Mockito.anyChar(), Mockito.any(BigDecimal.class), 
				Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(Pageable.class)))
			.thenThrow(ResourceNotFoundException.class);
		
		assertThrows(ResourceNotFoundException.class, () -> {
			this.controller.getDebitCreditPaymentFilter('C', "BOOK", new BigDecimal(10), new BigDecimal(100), "2023-06-09T10:00", "2023-06-09T12:00", "SCT", 0, 10);
		});
		
		verify(this.cgsService, times(1)).getDebitCreditPayment(Mockito.isNull(), Mockito.anyChar(), Mockito.any(BigDecimal.class), 
				Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(Pageable.class));
	}
	
	@Test
	@Order(14)
	void testGetDebitCreditPaymentFilterBicompException() throws ParseException {
		
		Mockito.when(this.cgsService.getDebitCreditPayment(Mockito.isNull(), Mockito.anyChar(), Mockito.any(BigDecimal.class), 
				Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(Pageable.class)))
			.thenThrow(ParseException.class);
		
		assertThrows(BicompException.class, () -> {
			this.controller.getDebitCreditPaymentFilter('C', "BOOK", new BigDecimal(10), new BigDecimal(100), "2023-06-09T10:00", "2023-06-09T12:00", "SCT", 0, 10);
		});
		
		verify(this.cgsService, times(1)).getDebitCreditPayment(Mockito.isNull(), Mockito.anyChar(), Mockito.any(BigDecimal.class), 
				Mockito.any(BigDecimal.class), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(Pageable.class));
	}*/
	
	@Test
	@Order(15)
	void testGetLastCgsBalanceParseException() throws ResourceNotFoundException, ParseException {
		
		Mockito.when(this.cgsService.getCgsLastBalanceByDate(Mockito.anyString())).thenThrow(ParseException.class);
		
		assertThrows(BicompException.class, () -> {
			this.controller.getLastCgsLac("01-09-2023");
		});
		
		verify(this.cgsService, times(1)).getCgsLastBalanceByDate(Mockito.anyString());
	}
	
	@Test
	@Order(16)
	void testGetCgsLacsParseException() throws ResourceNotFoundException, ParseException {
		
		Mockito.when(this.cgsService.getCurrentDateLac(Mockito.anyString())).thenThrow(ParseException.class);
		
		assertThrows(BicompException.class, () -> {
			this.controller.getCgsLacs("01-09-2023");
		});
		
		verify(this.cgsService, times(1)).getCurrentDateLac(Mockito.anyString());
	}
	
}
