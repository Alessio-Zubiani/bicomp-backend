package it.popso.bicomp.model;

public enum TimerStatusEnum {
	
	STARTED, EDITED, STOPPED, SCHEDULED, RUNNING

}
